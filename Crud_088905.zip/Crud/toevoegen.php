<?php
// Veronderstel dat je al een verbinding hebt gemaakt in 'config.php'
require 'config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['user_id'])) {
    $onderwerp = $_POST['onderwerp'];
    $inhoud = $_POST['inhoud'];
    $user_id = $_SESSION['user_id'];

    $sql = "INSERT INTO crud_agenda (Onderwerp, Inhoud, user_id) VALUES (?, ?, ?)";
    $stmt= $mysqli->prepare($sql);
    $stmt->bind_param("ssi", $onderwerp, $inhoud, $user_id);
    $stmt->execute();
}
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Voeg Bootstrap CSS toe -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
<body>

<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
    Onderwerp: <input type="text" name="onderwerp">
    Inhoud: <input type="text" name="inhoud">
    <input type="submit" href="toonagenda.php" >
</form>

</body>
</html>
