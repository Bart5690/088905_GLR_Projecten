<!DOCTYPE html>
<html>
<head>
    <!-- Voeg Bootstrap CSS toe -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1>Mijn Agenda</h1>
    <p>Dit is mijn agenda. Je kunt items toevoegen door op de knop hieronder te klikken.</p>
    <a href="toevoegen.php" class="btn btn-success">Toevoegen</a>
    <a href="signup.php" class="btn btn-primary">Aanmelden</a>
    <a href="login.php" class="btn btn-primary">Inloggen</a>

    <!-- Hier komt je PHP code -->
    <?php
    require 'config.php';

    $query = "SELECT * FROM crud_agenda";

    $result = mysqli_query($mysqli, $query);

    if (!$result) {
        echo "<p>FOUT </p>";
        echo "<p>" . $query . "</p>";
        echo "<p>" . mysqli_error($mysqli) . "</p>";
        exit;
    }

    if (mysqli_num_rows($result) > 0) {
        echo "<table class='table'>";
        echo "<tr><th>Onderwerp</th><th>Inhoud</th><th>Detail</th></tr>";

        while ($item = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $item['Onderwerp'] . "</td>";
            echo "<td>" . $item['Inhoud'] . "</td>";
            echo "<td><a href='detail.php?id=" . $item['ID'] . "'>Detail</a></td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p>Geen items gevonden!</p>";
    }
    ?>
</div>

<!-- Voeg Bootstrap JS toe -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js"></script>
</body>
</html>
