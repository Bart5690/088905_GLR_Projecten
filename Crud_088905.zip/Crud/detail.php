<?php
// Veronderstel dat je al een verbinding hebt gemaakt in 'config.php'
require 'config.php';

// Controleer of het ID is ingesteld
if (!isset($_GET['id'])) {
    echo "<p>Geen ID opgegeven!</p>";
    exit;
}

$id = $_GET['id'];

// Haal het item op uit de database
$query = "SELECT * FROM crud_agenda WHERE ID = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $item = $result->fetch_assoc();
    echo "<h1>" . $item['Onderwerp'] . "</h1>";
    echo "<p>" . $item['Inhoud'] . "</p>";
} else {
    echo "<p>Item niet gevonden!</p>";
}
?>
