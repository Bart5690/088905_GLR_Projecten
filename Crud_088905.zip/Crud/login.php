<?php
require 'config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Je bestaande code...

    if (password_verify($password, $user->password)) {
        $_SESSION['user_id'] = $user->id;
        echo "Je bent ingelogd!";
    } else {
        echo "Verkeerde gebruikersnaam of wachtwoord!";
    }
} else {
    // Je bestaande code...
}
?>
