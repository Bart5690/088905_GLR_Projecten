import express from 'express';


import { getRecepten, setRecept } from './recepten.js'; 

//maak server aan
const app = express();

// geef poortnummer op
const PORT = 3001;
app.use(express.json()); //

// GET /recepten
app.get('/recepten', getRecepten);

//start server
app.listen(PORT, () => {
    console.log(`Webserver draait op poort ${PORT}`);
    });