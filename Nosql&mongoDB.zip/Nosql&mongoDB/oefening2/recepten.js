import { client } from './dbconnect.js';

export const getRecepten = async (req, res) => {
    try {
        await client.connect();
        const dbName = "nogEentje"
        const collectionName = "receptjesInhetHollands"
        const database = client.db(dbName);
        const collection = database.collection(collectionName);
        const cursor = collection.find();
        const results = await cursor.toArray();
        console.log(results);
        if (results) { res.json(results); }
    } catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
};

export const setRecept = async (req, res) => {
    try {
        await client.connect();
        const dbName = "nogEentje";
        const collectionName = "receptjesInhetHollands";
        const database = client.db(dbName);
        const collection = database.collection(collectionName);
        const result = await collection.insertOne(req.body);
        console.log(result);
        res.status(201).json(result);
    } catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
};