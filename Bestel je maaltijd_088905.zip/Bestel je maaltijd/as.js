function btn() {
    window.alert("u hebt succesvol de email verzonden")
}