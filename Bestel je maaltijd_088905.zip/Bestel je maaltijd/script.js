const form = document.querySelector('form');

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const formData = new FormData(form);

    try {
        const response = await fetch('/send-email', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            form.reset();
            alert('Message sent successfully.');
        } else {
            throw new Error('Unable to send message.');
        }
    } catch (error) {
        console.error(error);
        alert('An error occurred while sending the message. Please try again later.');
    }
});
