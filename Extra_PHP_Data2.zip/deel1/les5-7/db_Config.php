<?php
$host = 'localhost:3306';
$dbUsername = "88905";
$dbPassword = "Walvis_69";
$dbName = "Data_2";

// Create a new MySQLi connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
