<?php
$host = "localhost";
$dbname = "Data_2";
$username = "88905";
$password = "Walvis_69";
 
try {
    $db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION)
    ;
} catch(PDOException $ex) {
    echo "Fout bij verbinden database: " . $ex->getMessage();
}

?>