<?php //Voeg de database-verbinding toe
require 'db_Config.php';
//Maak de query
$query = "SELECT * FROM Customers";
//Voer de query uit, en vang het resultaat op 
$result = mysqli_query($mysqli, $query); //Als er records zijn....
if (mysqli_num_rows($result) > 0)
{
//zolang er items uit te lezen zijn... 
    while ($item = mysqli_fetch_assoc($result)) {
    //Toon de gegevens van het item 
        echo $item['Onderwerp'] . " - "; 
        echo $item['Inhoud'] . "<br/>";
    }
}
//Als er geen records zijn...
else
{
    echo "<p>Geen items gevonden!</p>";
}