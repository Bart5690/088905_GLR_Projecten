<!DOCTYPE html>
<html>
<head>
    <title>Opdracht 3</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<h1>Add Student</h1>
<form method="POST" action="Opdracht3.php">
    Name: <input type="text" name="Naam" required><br>
    Class: <input type="text" name="Class" required><br>
    <input type="submit" value="Add Student">
</form>

<h1>Student Data</h1>
<div id="studentData"></div>

<script>

    function loadStudentData() {
        $.ajax({
            url: 'getStudents.php',
            dataType: 'json',
            success: function(data) {
                var table = '<table border="1"><tr><th>ID</th><th>Name</th><th>Class</th></tr>';
                for (var i = 0; i < data.length; i++) {
                    table += '<tr>';
                    table += '<td>' + data[i].ID + '</td>';
                    table += '<td>' + data[i].Naam + '</td>';
                    table += '<td>' + data[i].Klas + '</td>';
                    table += '</tr>';
                }
                table += '</table>';
                $('#studentData').html(table);
            },
            error: function() {
                alert('Error fetching data.');
            }
        });
    }

    loadStudentData();
</script>
</body>
</html>
