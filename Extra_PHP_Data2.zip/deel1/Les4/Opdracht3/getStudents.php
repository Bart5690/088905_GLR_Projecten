<?php
// Include the database configuration file created in Opdracht 1
include('db_Config.php');

// Select and fetch data from the Student table
$selectQuery = "SELECT * FROM Student";
$result = mysqli_query($conn, $selectQuery);

$students = array(); // Create an array to store the student data

while ($row = mysqli_fetch_assoc($result)) {
    $students[] = $row;
}

// Close the database connection
mysqli_close($conn);

// Return the student data as JSON
header('Content-Type: application/json');
echo json_encode($students);
?>
