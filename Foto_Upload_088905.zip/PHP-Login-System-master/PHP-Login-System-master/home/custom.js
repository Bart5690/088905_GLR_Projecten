document.addEventListener('DOMContentLoaded', function () {
    const zoomTriggers = document.querySelectorAll('.zoom-trigger');
    const zoomedImage = document.createElement('div');
    zoomedImage.classList.add('zoomed-image');
    const indicatorsContainer = document.createElement('div');
    indicatorsContainer.classList.add('indicators');

    let currentImageIndex = 0;

    zoomTriggers.forEach(function (trigger, index) {
        trigger.addEventListener('click', function (event) {
            event.preventDefault();
            currentImageIndex = index;
            const imageSrc = this.getAttribute('data-image');
            zoomedImage.innerHTML = '<img src="' + imageSrc + '" alt="Zoomed Image">';
            document.body.appendChild(zoomedImage);
            updateIndicators();
            addDownloadButton(imageSrc);
        });
    });

    function updateIndicators() {
        indicatorsContainer.innerHTML = '';
        zoomTriggers.forEach(function (_, index) {
            const indicator = document.createElement('div');
            indicator.classList.add('indicator');
            if (index === currentImageIndex) {
                indicator.classList.add('active');
            }
            indicator.addEventListener('click', function () {
                currentImageIndex = index;
                const imageSrc = zoomTriggers[currentImageIndex].getAttribute('data-image');
                zoomedImage.innerHTML = '<img src="' + imageSrc + '" alt="Zoomed Image">';
                updateIndicators();
                addDownloadButton(imageSrc);
            });
            indicatorsContainer.appendChild(indicator);
        });
        zoomedImage.appendChild(indicatorsContainer);
    }

    zoomedImage.addEventListener('click', function () {
        document.body.removeChild(zoomedImage);
    });

    const arrowLeft = document.createElement('div');
    arrowLeft.classList.add('arrow', 'left');
    arrowLeft.addEventListener('click', function () {
        currentImageIndex = (currentImageIndex - 1 + zoomTriggers.length) % zoomTriggers.length;
        const imageSrc = zoomTriggers[currentImageIndex].getAttribute('data-image');
        zoomedImage.innerHTML = '<img src="' + imageSrc + '" alt="Zoomed Image">';
        updateIndicators();
        addDownloadButton(imageSrc);
    });
    zoomedImage.appendChild(arrowLeft);

    const arrowRight = document.createElement('div');
    arrowRight.classList.add('arrow', 'right');
    arrowRight.addEventListener('click', function () {
        currentImageIndex = (currentImageIndex + 1) % zoomTriggers.length;
        const imageSrc = zoomTriggers[currentImageIndex].getAttribute('data-image');
        zoomedImage.innerHTML = '<img src="' + imageSrc + '" alt="Zoomed Image">';
        updateIndicators();
        addDownloadButton(imageSrc);
    });
    zoomedImage.appendChild(arrowRight);

    function addDownloadButton(imageSrc) {
        const downloadButton = document.createElement('a');
        downloadButton.classList.add('download-button');
        downloadButton.href = imageSrc;
        downloadButton.download = 'image.jpg';
        downloadButton.innerHTML = 'Download';
        zoomedImage.appendChild(downloadButton);
    }
});