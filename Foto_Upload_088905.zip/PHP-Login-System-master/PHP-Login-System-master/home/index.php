<?php

define('TITLE', "Home");
include '../assets/layouts/header.php';
include '../assets/setup/db.inc.php';

check_verified();

?>


<link rel="stylesheet" href="../home/custom.css">
<script src="../home/custom.js"></script>
<style>
    /* Add the provided CSS for the gallery layout */
    .row {
        display: flex;
        flex-wrap: wrap;
        padding: 0 4px;
    }

    /* Adjust the width of each column */
    .column {
        flex: 33.33%;
        padding: 0 4px;
        max-width: 33.33%;
    }

    .column img {
        margin-top: 8px;
        vertical-align: middle;
        width: 100%;
    }

    @media screen and (max-width: 800px) {
        .column {
            flex: 50%;
            max-width: 50%;
        }
    }

    @media screen and (max-width: 600px) {
        .column {
            flex: 33.33%;
            max-width: 33.33%;
        }
    }

    .image-container {
        position: relative;
        width: 100%;
    }

    .download-button {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        display: none;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
        padding: 10px;
        border-radius: 5px;
    }

    .image-container:hover .download-button {
        display: block;
    }

    /* Add CSS for zoomed-in image */
    .zoomed-image {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }

    .zoomed-image img {
        max-height: 80vh;
        max-width: 80vw;
    }

    /* Add CSS for image indicators */
    .indicators {
        position: absolute;
        bottom: 10px;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }

    .indicator {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #fff;
        margin: 0 5px;
        cursor: pointer;
    }

    .indicator.active {
        background-color: #000;
    }

    .arrow {
        width: 0;
        height: 0;
        border-top: 5px solid transparent;
        border-bottom: 5px solid transparent;
        cursor: pointer;
    }

    .arrow.left {
        border-right: 5px solid #fff;
        margin-right: 5px;
    }

    .arrow.right {
        border-left: 5px solid #fff;
        margin-left: 5px;
    }
</style>

<main role="main" class="container">
    <div class="row">
        <div class="col-sm-3">
            <?php include '../assets/layouts/profile-card.php'; ?>
        </div>
        <div class="col-sm-9">
            <div class="my-3 p-3 bg-white rounded box-shadow">
                <?php
                // Query to retrieve all images of the user
                $user_id = $_SESSION['id']; // Adjust according to your session implementation
                $sql = "SELECT image_path FROM user_images WHERE user_id = $user_id";
                // Execute the query and fetch the results
                $result = mysqli_query($conn, $sql);
                // Display the images
                $columns = array_fill(0, 3, '');
                $i = 0;
                foreach ($result as $row) {
                    $columns[$i] .= '<div class="image-container">';
                    $columns[$i] .= '<a href="#" class="zoom-trigger" data-image="../upload/images/' . $row['image_path'] . '">';
                    $columns[$i] .= '<img src="../upload/images/' . $row['image_path'] . '" alt="User Image" class="img-thumbnail">';
                    $columns[$i] .= '</a>';
                    $columns[$i] .= '<a id="downloadButton" class="download-button" href="#" download>Download</a>';
                    $columns[$i] .= '</div>';
                    $i = ($i + 1) % 3;
                }
                echo '<div class="row">';
                foreach ($columns as $column) {
                    echo '<div class="column">' . $column . '</div>';
                }
                echo '</div>';
                ?>
                <small class="d-block text-right mt-3">
                    <a href="#">All updates</a>
                </small>
            </div>
        </div>
    </div>
</main>

<!-- Add JavaScript for zoom functionality and indicators -->

<?php include '../assets/layouts/footer.php' ?>
