<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);


define('TITLE', "Upload");
include '../assets/layouts/header.php';
require_once '../assets/setup/db.inc.php';

check_verified();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Loop door alle geüploade bestanden
        // Controleer of er een fout is opgetreden bij het uploaden van het bestand
        if ($_FILES["filesToUpload"]["error"] !== UPLOAD_ERR_OK) {
            echo "Sorry, there was an error uploading your file. Error code: " . $_FILES["filesToUpload"]["error"];
        }

        $user_id = $_SESSION['id']; // Aanpassen aan jouw sessie implementatie
        // Hier gaat de rest van je uploadcode
        $target_file = $user_id . "_". basename($_FILES["filesToUpload"]["name"]);
        // Als de upload succesvol is, sla dan de afbeeldingslocatie op in de database
        if (!move_uploaded_file($_FILES["filesToUpload"]["tmp_name"], "images/".$target_file)) {
            echo "Failed to move uploaded file. Debugging information: " . print_r(error_get_last(), true);
        } else {
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'File Uploaded',
                    showConfirmButton: false,
                    timer: 1500
                });
            </script>";
            $image_path = $target_file;

            // Voeg de afbeeldingslocatie toe aan de database
            $sql = "INSERT INTO user_images (user_id, image_path) VALUES ($user_id, '$image_path')";
            // Voer de SQL-query uit
            mysqli_query($conn, $sql);
            // Controleer of de query succesvol is uitgevoerd en geef een melding weer
        }
    }
?>

<main role="main" class="container">
    <div class="row">
        <div class="col-sm-3">

            <?php include '../assets/layouts/profile-card.php'; ?>

        </div>
        <div class="col-sm-9">
            <div class="my-3 p-3 bg-white rounded box-shadow">
    <h2>Upload Images</h2>
    <form action="index.php" method="post" enctype="multipart/form-data" id="uploadForm">
        <!-- Update the form action to point to the correct file path -->
        <div class="custom-file mb-3">
            <input type="file" class="custom-file-input" id="filesToUpload" name="filesToUpload" multiple>
            <label class="custom-file-label" for="filesToUpload">Choose file</label>
        </div>
        <input type="submit" class="btn btn-primary" value="Upload" name="submit">
    </form>
    <div id="uploadStatus"></div>
</div>
        </div>

    </div>
</main>

<?php include '../assets/layouts/footer.php' ?>