<?php

if (!defined('APP_NAME'))                       define('APP_NAME', getenv('APP_NAME') ?: 'Foto_Upload');
if (!defined('APP_ORGANIZATION'))               define('APP_ORGANIZATION', getenv('APP_ORGANIZATION') ?: 'KLiK');
if (!defined('APP_OWNER'))                      define('APP_OWNER', getenv('APP_OWNER') ?: 'Bart & Mustafa');
if (!defined('APP_DESCRIPTION'))                define('APP_DESCRIPTION', getenv('APP_DESCRIPTION') ?: 'Login systeem met foto upload');

if (!defined('ALLOWED_INACTIVITY_TIME'))        define('ALLOWED_INACTIVITY_TIME', getenv('ALLOWED_INACTIVITY_TIME') ?: time()+30*60);

if (!defined('DB_DATABASE'))                    define('DB_DATABASE', getenv('DB_DATABASE') ?: 'Beroeps5690');
if (!defined('DB_HOST'))                        define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
if (!defined('DB_USERNAME'))                    define('DB_USERNAME', getenv('DB_USERNAME') ?: '88905');
if (!defined('DB_PASSWORD'))                    define('DB_PASSWORD', getenv('DB_PASSWORD') ?: 'Walvis_69');
if (!defined('DB_PORT'))                        define('DB_PORT', getenv('DB_PORT') ?: '3306');

if (!defined('MAIL_HOST'))                      define('MAIL_HOST', getenv('MAIL_HOST') ?: 'smtp.mailersend.net');
if (!defined('MAIL_USERNAME'))                  define('MAIL_USERNAME', getenv('MAIL_USERNAME') ?: 'MS_ocqSi5@trial-neqvygm950zl0p7w.mlsender.net');
if (!defined('MAIL_PASSWORD'))                  define('MAIL_PASSWORD', getenv('MAIL_PASSWORD') ?: 'UVPg2jfXaz5I3ygl');
if (!defined('MAIL_ENCRYPTION'))                define('MAIL_ENCRYPTION', getenv('MAIL_ENCRYPTION') ?: 'ssl');
if (!defined('MAIL_PORT'))                      define('MAIL_PORT', getenv('MAIL_PORT') ?: 587);
