<?php
  if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //var_dump($_POST);
      include 'database.php';
      $fouten = [];

      $voornaam = $_POST['voornaam'];
      $tussenvoegsel = $_POST['tussenvoegsel'];
      $achternaam = $_POST['achternaam'];
      $geboortedatum = $_POST['geboortedatum'];

      // controleer invoer op vereiste velden
      if (!isset($voornaam) || strlen($voornaam) === 0) {
        array_push($fouten, 'U moet een voornaam invullen');
      }
      if (!isset($achternaam) || strlen($achternaam) === 0) {
        array_push($fouten, 'U moet een achternaam invullen');
      }
      if (!isset($geboortedatum) || strlen($geboortedatum) === 0) {
        array_push($fouten, 'U moet een geboortedatum invullen');
      }
      var_dump($_FILES);
      // controleer of foto paspoort niet leeg is
      if (count($_FILES) > 0 && $_FILES['foto_paspoort']['size'] > 0) {
        // controleer bestandstype (mime type)
        $types = ['image/jpg', 'image/jpeg'];
        if (in_array($_FILES['foto_paspoort']['type'], $types)) {
          // controleer bestandsgrootte
          if ($_FILES['foto_paspoort']['size'] < 500000) {
            // controleer of bestand jpg- of png data bevat
            if (getimagesize($_FILES["foto_paspoort"]["tmp_name"]) !== false) {
              // alle gegevens lijken te kloppen, voeg toe aan database
              if ($klantId = $db->insertKlant($voornaam, $tussenvoegsel, $achternaam, $geboortedatum)) {
                // schrijf foto weg in uploads map met id van toegevoegde klant
                if (move_uploaded_file($_FILES["foto_paspoort"]["tmp_name"], 'uploads/foto_' . $klantId . '.jpg')) {
                  header('location:bedankt.php');
                } else {
                  array_push($fouten, 'Er ging iets mis bij het uploaden van de foto van uw paspoort');
                }
              } else {
                array_push($fouten, 'Er ging iets mis bij het opslaan van uw gegevens');
              }
            } else {
              array_push($fouten, 'De foto van uw paspoort is geen geldige afbeelding');
            }
          } else {
            array_push($fouten, 'De foto van uw paspoort mag maximaal 500 kilobyte zijn');
          }
        } else {
          array_push($fouten, 'De foto van uw paspoort moet een .jpg bestand zijn');
        }
      } else {
        array_push($fouten, 'U moet een foto van uw paspoort uploaden');
      }
    }
    ?>
    <!DOCTYPE html>
    <html>
      <title>Inschrijving</title>
      <link href="css/style.css" rel="stylesheet" type="text/css" />
      <body>
      <form method="post" action="#" enctype="multipart/form-data">
        <label for="voornaam">Voornaam:</label>
        <input type="text" id="voornaam" name="voornaam" placeholder="Voornaam" value="<?php if (isset($voornaam)) { echo $voornaam; } ?>">
        <label for="tussenvoegsel">Tussenvoegsel:</label>
        <input type="text" id="tussenvoegsel" name="tussenvoegsel" placeholder="Tussenvoegsel" value="<?php if (isset($tussenvoegsel)) { echo $tussenvoegsel; } ?>">
        <label for="achternaam">Achternaam:</label>
        <input type="text" id="achternaam" name="achternaam" placeholder="Achternaam" value="<?php if (isset($achternaam)) { echo $achternaam; } ?>">
        <label for="geboortedatum">Geboortedatum:</label>
        <input type="date" id="geboortedatum" name="geboortedatum" placeholder="Geboortedatum" value="<?php if (isset($geboortedatum)) { echo $geboortedatum; } ?>">
      <label for="foto_paspoort">Paspoort:</label>
      <input type="file" id="foto_paspoort" name="foto_paspoort" placeholder="Foto van paspoort">
      <label for="opslaan">Opslaan:</label>
      <input type="submit" id="opslaan" value="Opslaan" />
    </form>
  </body>
</html>
