<?php
error_reporting(E_ALL);
ini_set("display_errors", true);

include('database.php');

function applyPixelate($imagePath, $outputPath, $pixelSize, $x1, $y1, $x2, $y2, $x3, $y3, $x4, $y4) {
    $image = imagecreatefromjpeg($imagePath);

    $pixelRegion1 = imagecreatetruecolor($x2 - $x1, $y2 - $y1);
    imagecopyresized($pixelRegion1, $image, 0, 0, $x1, $y1, $x2 - $x1, $y2 - $y1, $x2 - $x1, $y2 - $y1);

    imagefilter($pixelRegion1, IMG_FILTER_PIXELATE, $pixelSize, true);

    imagecopyresampled($image, $pixelRegion1, $x1, $y1, 0, 0, $x2 - $x1, $y2 - $y1, $x2 - $x1, $y2 - $y1);

    $pixelRegion2 = imagecreatetruecolor($x4 - $x3, $y4 - $y3);
    imagecopyresized($pixelRegion2, $image, 0, 0, $x3, $y3, $x4 - $x3, $y4 - $y3, $x4 - $x3, $y4 - $y3);

    imagefilter($pixelRegion2, IMG_FILTER_PIXELATE, $pixelSize, true);

    imagecopyresampled($image, $pixelRegion2, $x3, $y3, 0, 0, $x4 - $x3, $y4 - $y3, $x4 - $x3, $y4 - $y3);

    imagejpeg($image, $outputPath);

    imagedestroy($image);
    imagedestroy($pixelRegion1);
    imagedestroy($pixelRegion2);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Overzicht</title>
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<?php
if (isset($_GET['id'])) {
    $klant = $db->getKlant(intval($_GET['id']));
    ?>
    <h1>Gegevens van <?= $klant['voornaam'] . ' ' . $klant['tussenvoegsel'] . ' ' . $klant['achternaam'] ?></h1>
    <table>
        <tr>
            <td>Voornaam:</td>
            <td><?= $klant['voornaam'] ?></td>
        </tr>
        <tr>
            <td>Achternaam:</td>
            <td><?= $klant['achternaam'] ?><?php if ($klant['tussenvoegsel']) {
                    echo(', ' . $klant['tussenvoegsel']);
                } ?></td>
        </tr>
    </table>
    <?php
    applyPixelate("uploads/foto_" . $klant['id'] . ".jpg", "uploads/foto_pixelated_" . $klant['id'] . ".jpg", 10, 10, 50, 190, 280, 385, 150, 485, 260);
    ?>
    <img src="uploads/foto_pixelated_<?= $klant['id'] ?>.jpg" alt="<?= $klant['voornaam'] . ' ' . $klant['tussenvoegsel'] . ' ' . $klant['achternaam'] ?>"/>
    
    <form action="export.php" method="post">
    <input type="hidden" name="id" value="<?= $klant['id'] ?>"/>
    <input type="submit" name="export" value="Download gegevens"/>
</form>
    <?php
} else {
    $klanten = $db->getKlanten();

    if (count($klanten) > 0) {
        ?>
        <h1>Klanten</h1>
        <table>
            <tr>
                <th></th>
            </tr>
            <?php
            foreach ($klanten as $klant) {
                ?>
                <tr>
                    <td><a href="?id=<?= $klant['id'] ?>"><?= $klant['achternaam'] ?>
                            <?= $klant['tussenvoegsel'] ?>,
                            <?= $klant['voornaam'] ?></a></td>
                </tr>
                <?php
            }
            ?>
        </table>
        <?php
    } else {
        ?>
        <p>Er zijn geen resulaten gevonden.</p>
        <?php
    }
}
?>
</body>
</html>