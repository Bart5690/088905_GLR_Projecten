<?php
include('database.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$db = new Database();

if(isset($_POST["export"]) && isset($_POST["id"])) {
    $id = intval($_POST["id"]);
    $klant = $db->getKlant($id);
    if ($klant) {
        $csvFile = tempnam(sys_get_temp_dir(), 'csv');
        $output = fopen($csvFile, "w");
        fputcsv($output, array('ID', 'Voornaam', 'Tussenvoegsel', 'Achternaam', 'Geboortedatum'));
        fputcsv($output, $klant);
        fclose($output);
        
        $zip = new ZipArchive();
        $zipFile = tempnam(sys_get_temp_dir(), 'zip');
        if ($zip->open($zipFile, ZipArchive::CREATE) === TRUE) {
            $zip->addFile($csvFile, 'data.csv');
            $zip->addFile("uploads/foto_pixelated_" . $klant['id'] . ".jpg", "foto_pixelated_" . $klant['id'] . ".jpg");
            $zip->close();
        }
        
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename=data.zip');
        readfile($zipFile);
        unlink($csvFile);
        unlink($zipFile);
    }
}
?>