<?php
$host = 'localhost:3306'; // de hostnaam
$dbname = 'VillaSite'; // de naam van de database
$user = 'stu89137'; // je gebruikersnaam
$password = 'ditiseenww'; // je wachtwoord

// Controleer of het formulier is ingediend
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verkrijg de gegevens uit het formulier
    $Naam = $_POST['Naam'];
    $Prijs = $_POST['Prijs'];

    // Maak een PDO-objectinstantie aan
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
        // Optioneel: stel PDO in om fouten te tonen
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Voer een query uit om de entiteit toe te voegen
        $stmt = $pdo->prepare("INSERT INTO Page1 (Naam, Prijs) VALUES (:Naam, :Prijs)");
        $stmt->execute(array('Naam' => $Naam, ':Prijs' => $Prijs));

        // Herleid de pagina om te voorkomen dat het formulier opnieuw wordt verzonden
        echo "<meta http-equiv='refresh' content='0'>";
        exit();
    } catch(PDOException $e) {}
}

// Maak een PDO-objectinstantie aan
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    // Optioneel: stel PDO in om fouten te tonen
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Voer een query uit om alle gegevens op te halen
    $stmt = $pdo->query("SELECT * FROM Page1");
} catch(PDOException $e) {
    echo "Verbinding met de database mislukt: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Index</title>
</head>
<body>
<p>
    <a href="Verwerk_view.php?page=home">Number 1</a><br>
    <a href="Verwerk_view.php?page=2">Number 2</a><br>
    <a href="Verwerk_view.php?page=3">Number 3</a><br>
</p>
View1
<h1>Bidding</h1>

<form action="" method="POST">
    <label for="Naam">Naam:</label>
    <input type="text" name="Naam" id="Naam" required>
    <br>
    <label for="Prijs">Hoeveelheid:</label>
    <input type="number" name="Prijs" id="Prijs" required>

    <input type="submit" value="Toevoegen">
</form>

<h1>Bids</h1>
<table>
    <thead>
    <tr>
        <th>Naam</th>
        <th>Hoeveelheid</th>
    </tr>
    </thead>
    <tbody>
    <?php while ($row = $stmt->fetch()) { ?>
        <tr>
            <td><?php echo $row["Naam"]; ?> </td>
            <td><?php echo $row["Prijs"]; ?></td>
        </tr>
    <?php } ?>

    </tbody>
</table>



</body>
</html>

