<?php
$host = 'localhost:3306'; // de hostnaam
$dbname = 'VillaSit'; // de naam van de database
$user = 'VillaSit'; // je gebruikersnaam
$password = 'Furb5690!'; // je wachtwoord
$id = $_GET['id']; //je id

// Controleer of het formulier is ingediend
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verkrijg de gegevens uit het formulier
    $Naam = $_POST['Naam'];
    $Prijs = $_POST['Prijs'];
    $id = $_POST['id'];

    // zorg ervoor dat het bod niet lager kan zijn dan een miljoen en vorige bod
    if ($Prijs < 1000000) {
        $error = 'Het bod moet hoger zijn dan 1 miljoen';
    } elseif ($Prijs < $Prijs) {
        $error = 'Het bod moet hoger zijn dan het vorige bod';
    } else {


    // Maak een PDO-objectinstantie aan

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
        // Optioneel: stel PDO in om fouten te tonen
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Voer een query uit om de entiteit toe te voegen
        $stmt = $pdo->prepare("INSERT INTO biedingen(villaID, naam, hoeveelheid) VALUES (:villaID, :naam, :hoeveelheid)");
        $stmt->bindParam(':naam', $Naam);
        $stmt->bindParam(':villaID', $id);
        $stmt->bindParam(':hoeveelheid', $Prijs);
        $stmt->execute();

        //hoogste bod komt bovenaan te staan
        $stmt = $pdo->prepare("SELECT * FROM biedingen WHERE villaID = $id ORDER BY hoeveelheid DESC");




        // Herleid de pagina om te voorkomen dat het formulier opnieuw wordt verzonden
    } catch(PDOException $e) {}
}
}


// Maak een PDO-objectinstantie aan
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    // Optioneel: stel PDO in om fouten te tonen
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Voer een query uit om alle gegevens op te halen
    $stmt = $pdo->query("SELECT * FROM Villa WHERE id = $id ");
    $naamvilla = '';
    $villabeschrijving = '';
    $villadres = '';
    while ($row = $stmt->fetch()) {
        $villabeschrijving = $row['beschrijving'];
        $naamvilla = $row['naam'];
        $villadres = $row['adres'];
    }
} catch(PDOException $e) {
    echo "Verbinding met de database mislukt: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />


    <meta name="description" content="" />
    <meta name="keywords" content="bootstrap, bootstrap5" />


    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="fonts/icomoon/style.css" />
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css" />

    <link rel="stylesheet" href="css/tiny-slider.css" />
    <link rel="stylesheet" href="css/aos.css" />
    <link rel="stylesheet" href="css/style.css" />

    <title>
      Villa te koop
    </title>
  </head>
  <body>
    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close">
          <span class="icofont-close js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    <nav class="site-nav">
        <div class="container">
            <div class="menu-bg-wrap">
                <div class="site-navigation">
                    <a href="index.php" class="logo m-0 float-start">VillaTeKoop</a>

                    <ul
                        class="js-clone-nav d-none d-lg-inline-block text-start site-menu float-end"
                    >
                        <li class="active"><a href="index.php">Home</a></li>
                        <li class="has-children">
                            <a href="property-single.php.php">Huizen</a>
                            <ul class="dropdown">
                                <li><a href="property-single.php?id=1">Huis 1</a></li>
                                <li><a href="property-single.php?id=2">Huis 2</a></li>
                                <li><a href="property-single.php?id=3">Huis 3</a></li>

                            </ul>
                        </li>

                        <li><a href="contact.php">Contact ons</a></li>
                    </ul>

                    <a
                        href="#"
                        class="burger light me-auto float-end mt-1 site-menu-toggle js-menu-toggle d-inline-block d-lg-none"
                        data-toggle="collapse"
                        data-target="#main-navbar"
                    >
                        <span></span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div
      class="hero page-inner overlay"
      style="background-image: url('images/Home<?php echo $id?>.1.jpg')"
    >
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-lg-9 text-center mt-5">
            <h1 class="heading" data-aos="fade-up">
                <?php echo $naamvilla; ?><br/>

            </h1>

            <nav
              aria-label="breadcrumb"
              data-aos="fade-up"
              data-aos-delay="200"
            >
              <ol class="breadcrumb text-center justify-content-center">
                <li class="breadcrumb-item"><a href="index.php">Huis 3</a></li>
                <li class="breadcrumb-item">
                  <a href="properties.php">Huis 2</a>
                </li>
                <li
                  class="breadcrumb-item active text-white-50"
                  aria-current="page"
                >
                  Huis 1
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>

    <div class="section">
      <div class="container">
        <div class="row justify-content-between">
          <div class="col-lg-7">
            <div class="img-property-slide-wrap">
              <div class="img-property-slide">
                <img src="images/huis<?php echo $id?>_1.jpg" alt="Image" class="img-fluid" />
                  <img src="images/huis<?php echo $id?>_2.jpg" alt="Image" class="img-fluid" />
                  <img src="images/huis<?php echo $id?>_3.jpg" alt="Image" class="img-fluid" />
              </div>
            </div>
              <h1 class="text-center rounded mx-auto">Locatie</h1>
              <div class="embed-responsive embed-responsive-4by3">

              <?php

                     if ($id == 1){
                        echo '<iframe class="rounded mx-auto d-block" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2448.8255823670456!2d4.374438411028702!3d52.13749416436334!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c5b843e83947a5%3A0x9cb44c9fa7fabbad!2sHertelaan%2015%2C%202243%20EK%20Wassenaar!5e0!3m2!1snl!2snl!4v1686297401982!5m2!1snl!2snl" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>';
                    }
                    elseif($id == 2){
                          echo '<iframe class="rounded mx-auto d-block" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2442.115002848198!2d5.208759211038546!3d52.2594566553715!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c614dafa57fe11%3A0xd8dd3d6fe6f79d1d!2sSteenbergen%204%2C%201251%20CL%20Laren!5e0!3m2!1snl!2snl!4v1686297109173!5m2!1snl!2snl" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>';
                    }
                    elseif ($id == 3){
                          echo '<iframe class="rounded mx-auto d-block" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2450.034037657543!2d4.349114011026902!3d52.115509465982576!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c5b9d4b097d317%3A0xd17649032e75c7bc!2sBuurtweg%2087%2C%202244%20AB%20Wassenaar!5e0!3m2!1snl!2snl!4v1686297453250!5m2!1snl!2snl" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>';
                    }

                ?>
                  </div>

          </div>
          <div class="col-lg-4">
            <h2 class="heading text-primary"><?php echo $villadres; ?><br/></h2>

            <p class="text-black-50">
                <?php echo $villabeschrijving; ?><br/>
            </p>


            <div class="d-block agent-box p-5">
            <!DOCTYPE html>


<body>
    <h1 class="text-center">Bieden</h1>

    <form method="POST">
        <input type="hidden" name="id" value="<?php echo $id?>">
        <label for="Naam">Naam:</label>
        <input type="text" name="Naam" id="Naam" required>
<br>
        <label for="Prijs">Hoeveelheid:</label>
        <input type="number" name="Prijs" id="Prijs" required>

        <input type="submit" value="Toevoegen">
    </form>
</body>


            
<body>
<h1 class="text-center">Biedingen</h1>
<div class="container">

    <table class="table table-hover">
        <thead>
        <tr>
            <thead class="thead-dark">
            <th scope="col" >Naam</th>
            <th scope="col" >Hoeveelheid</th>
            </thead>
        </tr>
                  <?php
                  $query = "SELECT * FROM biedingen WHERE villaID = $id ORDER BY hoeveelheid DESC LIMIT 3";

                  $stmt = $pdo->query($query);

                  while ($row = $stmt->fetch()) { ?>
                <tr>
                    <td><?php echo $row["naam"]; ?> </td>
                    <td>$<?php echo $row["hoeveelheid"]; ?></td>
                </tr>
        </thead>


                  <?php } ?>

                  </tbody>
              </table>
            </div>
</body>


              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="widget">
                        <h3>Contact</h3>
                        <address>Rotterdam Grafisch lyceum</address>
                        <ul class="list-unstyled links">
                            <li><a href="tel://0683842900">0683842900</a></li>
                            <li><a href="tel://0611111111">0611111111</a></li>
                            <li>
                                <a href="88905@glr.nl">Barts email (88905@glr.nl)</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.widget -->
                </div>
                <!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="widget">
                        <h3>Huizen</h3>
                        <ul class="list-unstyled links">
                            <li><a href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=1">Huis 1</a></li>
                            <li><a href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=2">Huis 2</a></li>
                            <li><a href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=3">Huis 3</a></li>


                    </div>
                    <!-- /.widget -->
                </div>
                <!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="widget">
                        <h3>Links</h3>
                        <ul class="list-unstyled links">

                            <li><a href="overons">Over ons</a></li>
                            <li><a href="contact.php">Contact ons</a></li>
                        </ul>


                    </div>

                </div>

            </div>

    <!-- Preloader -->
    <div id="overlayer"></div>
    <div class="loader">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/tiny-slider.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>
