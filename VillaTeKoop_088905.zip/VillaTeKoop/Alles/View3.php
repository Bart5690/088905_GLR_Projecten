<?php
$host = 'localhost:3306'; // the hostname
$dbname = 'VillaSite'; // the database name
$user = 'stu89137'; // your username
$password = 'ditiseenww'; // your password

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the form
    $Naam = $_POST['Naam'];
    $Prijs = $_POST['Prijs'];

    // Create a PDO object instance
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
        // Optional: set PDO to display errors
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Execute a query to insert the entity
        $stmt = $pdo->prepare("INSERT INTO Page3 (Naam, Prijs) VALUES (:Naam, :Prijs)");
        $stmt->execute(array(':Naam' => $Naam, ':Prijs' => $Prijs));

        // Reload the page to display the updated table
        echo "<meta http-equiv='refresh' content='0'>";
    } catch(PDOException $e) {
        echo "Connection to the database failed: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Index</title>
</head>
<body>
<p>
    <a href="Verwerk_view.php?page=home">Number 1</a><br>
    <a href="Verwerk_view.php?page=2">Number 2</a><br>
    <a href="Verwerk_view.php?page=3">Number 3</a><br>
</p>

View3

<h1>Bidding</h1>

<form action="" method="POST">
    <label for="Naam">Name:</label>
    <input type="text" name="Naam" id="Naam" required>
    <br>
    <label for="Prijs">Amount:</label>
    <input type="number" name="Prijs" id="Prijs" required>

    <input type="submit" value="Add">
</form>

<h1>Bids</h1>
<table>
    <thead>
    <tr>
        <th>Name</th>
        <th>Amount</th>
    </tr>
    </thead>
    <tbody>
    <?php
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $pdo->query("SELECT * FROM Page3");

        while ($row = $stmt->fetch()) {
            echo "<tr>";
            echo "<td>" . $row["Naam"] . "</td>";
            echo "<td>" . $row["Prijs"] . "</td>";
            echo "</tr>";
        }
    } catch(PDOException $e) {
        echo "Connection to the database failed: " . $e->getMessage();
    }
    ?>

    </tbody>
</table>

</body>
</html>
