<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <meta name="description" content="" />
    <meta name="keywords" content="bootstrap, bootstrap5" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="fonts/icomoon/style.css" />
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css" />

    <link rel="stylesheet" href="css/tiny-slider.css" />
    <link rel="stylesheet" href="css/aos.css" />
    <link rel="stylesheet" href="css/style.css" />

    <title>
      Villa te koop
    </title>
  </head>
  <body>
    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close">
          <span class="icofont-close js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    <nav class="site-nav">
      <div class="container">
        <div class="menu-bg-wrap">
          <div class="site-navigation">
            <a href="index.php" class="logo m-0 float-start">VillaTeKoop</a>

            <ul
              class="js-clone-nav d-none d-lg-inline-block text-start site-menu float-end"
            >
              <li class="active"><a href="index.php">Home</a></li>
              <li class="has-children">
                <a href="property-single.php.php">Huizen</a>
                <ul class="dropdown">
                  <li><a href="property-single.php?id=1">Huis 1</a></li>
                  <li><a href="property-single.php?id=2">Huis 2</a></li>
                  <li><a href="property-single.php?id=3">Huis 3</a></li>
                  
                </ul>
              </li>

              <li><a href="contact.php">Contact ons</a></li>
            </ul>

            <a
              href="#"
              class="burger light me-auto float-end mt-1 site-menu-toggle js-menu-toggle d-inline-block d-lg-none"
              data-toggle="collapse"
              data-target="#main-navbar"
            >
              <span></span>
            </a>
          </div>
        </div>
      </div>
    </nav>

    <div class="hero">
      <div class="hero-slide">
        <div
          class="img overlay"
          style="background-image: url('images/huis1_2.jpg')"
        ></div>
        <div
          class="img overlay"
          style="background-image: url('images/huis2_2.jpg')"
        ></div>
        <div
          class="img overlay"
          style="background-image: url('images/hero_bg_1.jpg')"
        ></div>
      </div>

      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-lg-9 text-center">
            <h1 class="heading" data-aos="fade-up">
              Makkelijkste manier om je nieuwe huis te vinden.
            </h1>
            <form
              action="#"
              class="narrow-w form-search d-flex align-items-stretch mb-3"
              data-aos="fade-up"
              data-aos-delay="200"
            >
              <input
                type="text"
                class="form-control px-4"
                placeholder="Je ZIP code of plaatsnaam..."
              />
              <button type="submit" class="btn btn-primary">Zoek</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="section">
      <div class="container">
        <div class="row mb-5 align-items-center">
          <div class="col-lg-6">
            <h2 class="font-weight-bold text-primary heading">
              Populaire huizen
            </h2>
          </div>
          <div class="col-lg-6 text-lg-end">
            <p>
              <a
                href="#"
                target="_blank"
                class="btn btn-primary text-white py-3 px-4"
                >Bezoek alle huizen</a
              >
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="property-slider-wrap disabled">
              <div class="property-slider disabled">
                <div class="property-item disabled">
                  <a href="property-single.php" class="img disabled">
                    <img src="https://cloud.funda.nl/valentina_media/151/278/104_1080x720.jpg" alt="Image" class="img-fluid disabled" />
                  </a>

                  <div class="property-content">
                    <div class="price mb-2"><span>$5,290,00/</span></div>
                    <div>
                      <span class="d-block mb-2 text-black-50 disabled"
                        >Flevolaan 3 1272 PB</span
                      >
                      <span class="city d-block mb-3 disabled">Flevolaan, Nederland</span>

                      <div class="specs d-flex mb-4">
                        <span class="d-block d-flex align-items-center me-3">
                          <span class="icon-bed me-2"></span>
                          <span class="caption">8 slaapkamers</span>
                        </span>
                        <span class="d-block d-flex align-items-center">
                          <span class="icon-bath me-2"></span>
                          <span class="caption">6 badkamers</span>
                        </span>
                      </div>

                      <a
                        href="property-single.php"
                        class="btn btn-danger py-2 px-3 disabled"
                        >Kijk details</a
                      >
                    </div>
                  </div>
                </div>
                <!-- .item -->

                <div class="property-item">
                  <a href="property-single.php?id=2" class="img">
                    <img src="https://cloud.funda.nl/valentina_media/151/278/102_1080x720.jpg" alt="Image" class="img-fluid" />
                  </a>

                  <div class="property-content">
                    <div class="price mb-2"><span>$5,850,000</span></div>
                    <div>
                      <span class="d-block mb-2 text-black-50"
                        >Steenbergen 2 d
                        1251 CL Laren (NH)</span
                      >
                      <span class="city d-block mb-3">Steenbergen, Nederland</span>

                      <div class="specs d-flex mb-4">
                        <span class="d-block d-flex align-items-center me-3">
                          <span class="icon-bed me-2"></span>
                          <span class="caption">5 slaapkamers</span>
                        </span>
                        <span class="d-block d-flex align-items-center">
                          <span class="icon-bath me-2"></span>
                          <span class="caption">5 badkamers</span>
                        </span>
                      </div>

                      <a
                        href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=2"
                        class="btn btn-primary py-2 px-3"
                        >Kijk details</a
                      >
                    </div>
                  </div>
                </div>
                <!-- .item -->

                <div class="property-item">
                  <a href="property-single.php" class="img">
                    <img src="https://cloud.funda.nl/valentina_media/161/519/720_1080x720.jpg" alt="Image" class="img-fluid" />
                  </a>

                  <div class="property-content">
                    <div class="price mb-2"><span>$11,950,000</span></div>
                    <div>
                      <span class="d-block mb-2 text-black-50"
                        >Hertelaan 15
                        2243 EK Wassenaar</span
                      >
                      <span class="city d-block mb-3">Hertelaan, Nederland</span>

                      <div class="specs d-flex mb-4">
                        <span class="d-block d-flex align-items-center me-3">
                          <span class="icon-bed me-2"></span>
                          <span class="caption">6 slaapkamers</span>
                        </span>
                        <span class="d-block d-flex align-items-center">
                          <span class="icon-bath me-2"></span>
                          <span class="caption">5 badkamers</span>
                        </span>
                      </div>

                      <a
                        href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=1"
                        class="btn btn-primary py-2 px-3"
                        >Kijk details</a
                      >
                    </div>
                  </div>
                </div>
                <!-- .item -->

                <div class="property-item">
                  <a href="property-single.php" class="img">
                    <img src="https://cloud.funda.nl/valentina_media/154/351/083_1080x720.jpg" alt="Image" class="img-fluid" />
                  </a>

                  <div class="property-content">
                    <div class="price mb-2"><span>$3,769,00</span></div>
                    <div>
                      <span class="d-block mb-2 text-black-50"
                        >Palestrinalaan 11 1217 CD Hilversum</span
                      >
                      <span class="city d-block mb-3">Palestrinalaan, Nederland</span>

                      <div class="specs d-flex mb-4">
                        <span class="d-block d-flex align-items-center me-3">
                          <span class="icon-bed me-2"></span>
                          <span class="caption">5 slaapkamers</span>
                        </span>
                        <span class="d-block d-flex align-items-center">
                          <span class="icon-bath me-2"></span>
                          <span class="caption">3 badkamers</span>
                        </span>
                      </div>

                      <a
                        href="property-single.php"
                        class="btn btn-danger py-2 px-3 disabled"
                        >Kijk details</a
                      >
                    </div>
                  </div>
                </div>
                <!-- .item -->

                <div class="property-item">
                  <a href="property-single.php?id=2" class="img">
                    <img src="https://cloud.funda.nl/valentina_media/149/848/006_1080x720.jpg" alt="Image" class="img-fluid" />
                  </a>

                  <div class="property-content">
                    <div class="price mb-2"><span>$7,350,000</span></div>
                    <div>
                      <span class="d-block mb-2 text-black-50"
                        >Buurtweg 87
                        2244 AB Wassenaar</span
                      >
                      <span class="city d-block mb-3">Buurtweg, Nederland</span>

                      <div class="specs d-flex mb-4">
                        <span class="d-block d-flex align-items-center me-3">
                          <span class="icon-bed me-2"></span>
                          <span class="caption">8 slaapkamers</span>
                        </span>
                        <span class="d-block d-flex align-items-center">
                          <span class="icon-bath me-2"></span>
                          <span class="caption">4 Badkamers</span>
                        </span>
                      </div>

                      <a
                        href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=3"
                        class="btn btn-primary py-2 px-3"
                        >Kijk details</a
                      >
                    </div>
                  </div>
                </div>
                <!-- .item -->

                <div class="property-item">
                  <a href="property-single.php?id=1" class="img">
                    <img src="https://cloud.funda.nl/valentina_media/110/034/685_1080x720.jpg" alt="Image" class="img-fluid" />
                  </a>

                  <div class="property-content">
                    <div class="price mb-2"><span>$2,709,000</span></div>
                    <div>
                      <span class="d-block mb-2 text-black-50"
                        >5232 California Fake, Ave. 21BC</span
                      >
                      <span class="city d-block mb-3">Platteweg, Nederland</span>

                      <div class="specs d-flex mb-4">
                        <span class="d-block d-flex align-items-center me-3">
                          <span class="icon-bed me-2"></span>
                          <span class="caption">5 Slaapkamers</span>
                        </span>
                        <span class="d-block d-flex align-items-center">
                          <span class="icon-bath me-2"></span>
                          <span class="caption">2 Badkamers</span>
                        </span>
                      </div>

                      <a
                        href="property-single.php"
                        class="btn btn-danger py-2 px-3 disabled"
                        >Kijk details</a
                      >
                    </div>
                  </div>
                </div>
                
               
              
              </div>

              <div
                id="property-nav"
                class="controls"
                tabindex="0"
                aria-label="Carousel Navigation"
              >
                <span
                  class="prev"
                  data-controls="prev"
                  aria-controls="property"
                  tabindex="-1"
                  >Vorige</span
                >
                <span
                  class="next"
                  data-controls="next"
                  aria-controls="property"
                  tabindex="-1"
                  >Volgende</span
                >
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <section class="features-1">
      <div class="container">
        <div class="row">
          <div class="col-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
            <div class="box-feature">
              <span class="flaticon-house"></span>
              <h3 class="mb-3">Onze Huizen</h3>
              <p>
                Wij hebben hoog kwaliteit huizen. Wij hebben huizen in verschillende prijsklasse. Wij hebben huizen in verschillende plaatsen.
              </p>
              <p><a href="#" class="learn-more">Leer meer</a></p>
            </div>
          </div>
          <div class="col-6 col-lg-3" data-aos="fade-up" data-aos-delay="500">
            <div class="box-feature">
              <span class="flaticon-building"></span>
              <h3 class="mb-3">Huis ter verkoop</h3>
              <p>
                Al onze huizen zijn te koop. Je kunt er zelf op bieden en natuurlijk de persoon met het hoogste bod zal het huis krijgen.
              </p>
              <p><a href="#" class="learn-more">Leer meer</a></p>
            </div>
          </div>
          <div class="col-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
            <div class="box-feature">
              <span class="flaticon-house-3"></span>
              <h3 class="mb-3">Real Estate Agent</h3>
              <p>
                Wij zijn Proffesionel Real Estate Agents. Wij hebben al jaren ervaring in het vak en weten precies wat we doen.
              </p>
              <p><a href="#" class="learn-more">Leer meer</a></p>
            </div>
          </div>
          <div class="col-6 col-lg-3" data-aos="fade-up" data-aos-delay="600">
            <div class="box-feature">
              <span class="flaticon-house-1"></span>
              <h3 class="mb-3">Legit en veilig</h3>
              <p>
                Al onze huizen getest op veiligheid. De foto´s die u heeft gezien zijn ook voorkomen legit en geen scam. en altijd garantie.
              </p>
              <p><a href="#" class="learn-more">Leer meer</a></p>
            </div>
          </div>
        </div>
      </div>
    </section>

    





    <div id="overons"
        class="section section-5 bg-white">
      <div class="container">
        <div class="row justify-content-center text-center mb-5">
          <div class="col-lg-6 mb-5">
            <h2 class="font-weight-bold heading text-primary mb-4">
              Over ons
            </h2>
            <p class="text-black-50">
              Hieronder zie je de 3 mensen die aan deze opdracht hebben gewerkt voor beroeps Villa Te Koop.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0">
            <div class="h-100 person">
              <img
                src="../Alles/images/Mattia.jpg"
                alt="Image"
                class="img-fluid"
              />

              <div class="person-contents">
                <h2 class="mb-0"><a href="#">Mattia </a></h2>
                <span class="meta d-block mb-3">Software develepor</span>
                <p>
                  Mattia heeft geholpen met het maken van de website. Hij heeft verschillende dingen gedaan zoals hte maken van de website, de database en andere handige dingen.
                </p>


              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0">
            <div class="h-100 person">
              <img
                src="../Alles/images/adobe.png"
                alt="Image"
                class="img-fluid"
              />

              <div class="person-contents">
                <h2 class="mb-0"><a href="#">Bart van wijk</a></h2>
                <span class="meta d-block mb-3">Software develepor</span>
                <p>
                  Bart maakt deel uit van dit team. Hij heeft onderandere de planning gemaakt en de website een goed zetje gegeven met behulp van bootstrap. Daarnaast heeft hij ook geholpen met het maken van de database en bieding systeem.
                </p>


              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0">
            <div class="h-100 person">
              <img
                src="images/Micheal.jpg"
                alt="Image"
                class="img-fluid"
              />

              <div class="person-contents">
                <h2 class="mb-0"><a href="#">Micheal Janzen</a></h2>
                <span class="meta d-block mb-3">Software develepor</span>
                <p>
                  Micheal Janzen is een van de 3 mensen die aan de opdracht heeft gewerkt en meegeholpen.
                </p>


              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="widget">
              <h3>Contact</h3>
              <address>Rotterdam Grafisch lyceum</address>
              <ul class="list-unstyled links">
                <li><a href="tel://0683842900">0683842900</a></li>
                <li><a href="tel://0611111111">0611111111</a></li>
                <li>
                  <a href="88905@glr.nl">Barts email (88905@glr.nl)</a>
                </li>
              </ul>
            </div>
            <!-- /.widget -->
          </div>
          <!-- /.col-lg-4 -->
          <div class="col-lg-4">
            <div class="widget">
              <h3>Huizen</h3>
                <ul class="list-unstyled links">
                <li><a href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=1">Huis 1</a></li>
                <li><a href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=2">Huis 2</a></li>
                <li><a href="https://88905.stu.sd-lab.nl/VillaTeKoop/Alles/property-single.php?id=3">Huis 3</a></li>


            </div>
            <!-- /.widget -->
          </div>
          <!-- /.col-lg-4 -->
          <div class="col-lg-4">
            <div class="widget">
              <h3>Links</h3>
              <ul class="list-unstyled links">

                <li><a href="overons">Over ons</a></li>
                <li><a href="contact.php">Contact ons</a></li>
              </ul>


            </div>
      
          </div>
      
        </div>


        <div class="row mt-5">
          <div class="col-12 text-center">
       

            
           
          </div>
        </div>
      </div>

    </div>



    <div id="overlayer"></div>
    <div class="loader">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/tiny-slider.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>
