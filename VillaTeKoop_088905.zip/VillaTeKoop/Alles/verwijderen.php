<!DOCTYPE html>
<html>
<head>
    <title>Entiteit Verwijderen</title>
</head>
<body>
    <h1>Entiteit Verwijderen</h1>

    <form action="Index.php" method="POST">
        <label for="id">ID:</label>
        <input type="text" name="id" id="id" required>

        <input type="submit" value="Verwijderen">
    </form>
</body>
</html>

<?php
$host = 'localhost:3306'; // de hostnaam
$dbname = 'db_89137'; // de naam van de database
$user = '89137'; // je gebruikersnaam
$password = 'ditiseenww'; // je wachtwoord

// Verkrijg de ID uit het formulier
$id = $_POST['id'];

// Maak een PDO-objectinstantie aan
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    // Optioneel: stel PDO in om fouten te tonen
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Voer een query uit om de entiteit te verwijderen
    $stmt = $pdo->prepare("DELETE FROM Animes WHERE ID = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();

    echo "Entiteit succesvol verwijderd uit de database.";
} catch(PDOException $e) {
    echo "Fout bij verwijderen van entiteit uit de database: " . $e->getMessage();
}
?>


