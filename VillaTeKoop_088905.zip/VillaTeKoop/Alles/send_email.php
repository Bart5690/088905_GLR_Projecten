<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $naam = $_POST["naam"];
    $email = $_POST["email"];
    $onderwerp = $_POST["onderwerp"];
    $bericht = $_POST["bericht"];

    $to = $email; // Send email to the person who filled out the form
    $subject = "Contact Form Submission";
    $message = "Name: " . $naam . "\r\n";
    $message .= "Email: " . $email . "\r\n";
    $message .= "Subject: " . $onderwerp . "\r\n";
    $message .= "Message: " . $bericht . "\r\n";
    $headers = "bartvanwijk01@gmail.com\r\n"; // Set the sender's email address

    if (mail($to, $subject, $message, $headers)) {
        echo "Email sent successfully.";
    } else {
        echo "Failed to send email.";
    }
}
?>
