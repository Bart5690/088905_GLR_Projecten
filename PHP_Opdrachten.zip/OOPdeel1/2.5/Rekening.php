<?php
class Rekening {
    public $rekeningNummer;  // Eigenschap blijft public
    private $naamEigenaar;  // Eigenschap is private
    private $saldo;  // Eigenschap is private
    private $opnameLimiet;  // Eigenschap is private
    private $maxRood;  // Eigenschap is private

    public function __construct($rekeningNummer, $naamEigenaar, $saldo, $opnameLimiet, $maxRood) {
        $this->rekeningNummer = $rekeningNummer;
        $this->naamEigenaar = $naamEigenaar;
        $this->saldo = $saldo;
        $this->opnameLimiet = $opnameLimiet;
        $this->maxRood = $maxRood;
    }

    public function getNaam() {
        return $this->naamEigenaar;
    }

    public function getSaldo() {
        return $this->saldo;
    }

    public function storten($bedrag) {
        if (is_numeric($bedrag) && $bedrag > 0) {
            $this->saldo += $bedrag;
            return "Storting succesvol. Nieuw saldo: €" . $this->saldo;
        } else {
            return "Ongeldige stortingswaarde.";
        }
    }

    public function opnemen($bedrag) {
        if (is_numeric($bedrag) && $bedrag > 0 && $bedrag <= $this->opnameLimiet && ($this->saldo - $bedrag) >= $this->maxRood) {
            $this->saldo -= $bedrag;
            return "Opname succesvol. Nieuw saldo: €" . $this->saldo;
        } else {
            return "Ongeldige opnamewaarde of saldo ontoereikend.";
        }
    }

    public function pasOpnameLimietAan($nieuwLimiet) {
        if (is_numeric($nieuwLimiet) && $nieuwLimiet >= 0) {
            $this->opnameLimiet = $nieuwLimiet;
            return "Opnamelimiet is aangepast naar €" . $nieuwLimiet;
        } else {
            return "Ongeldige opnamelimietwaarde.";
        }
    }

    public function pasMaxRoodAan($nieuwMaxRood) {
        if (is_numeric($nieuwMaxRood)) {
            $this->maxRood = $nieuwMaxRood;
            return "Maximale roodstand is aangepast naar €" . $nieuwMaxRood;
        } else {
            return "Ongeldige maximale roodstandwaarde.";
        }
    }
}
?>
