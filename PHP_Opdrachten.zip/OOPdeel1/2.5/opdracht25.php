<?php
require_once 'Rekening.php';

// Maak een object van de class Rekening
$rekening = new Rekening("88905", "Bart", 1000, 500, -1000);

// Test getter-methoden
$naamEigenaar = $rekening->getNaam();
$saldo = $rekening->getSaldo();

echo "Naam eigenaar: " . $naamEigenaar . "<br>";
echo "Saldo: €" . $saldo . "<br>";

// Probeer toegang tot private eigenschappen (moet een fout genereren)
// echo "Naam eigenaar: " . $rekening->naamEigenaar . "<br>";
// echo "Saldo: €" . $rekening->saldo . "<br>";
?>

