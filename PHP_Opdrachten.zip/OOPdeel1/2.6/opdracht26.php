<?php
require_once 'Spaarrekening.php';
require_once 'Beleggingsrekening.php';

// Maak objecten van de child-classes
$spaarRekening = new Spaarrekening("12345", "Alice", 1000, 500, -1000, "2023-01-01", 0.03, 10);
$beleggingsRekening = new Beleggingsrekening("54321", "Bob", 2000, 1000, -2000, "2023-01-01", 0.05, 500);

// Test en toon de resultaten
echo "Spaarrekening gegevens:<br>";
echo "Saldo: €" . $spaarRekening->getSaldo() . "<br>";
echo "Rente: " . ($spaarRekening->getRente() * 100) . "%<br>";
echo "Kosten: €" . $spaarRekening->getKosten() . "<br>";

echo "<br>";

echo "Beleggingsrekening gegevens:<br>";
echo "Saldo: €" . $beleggingsRekening->getSaldo() . "<br>";
echo "Inleg: €" . $beleggingsRekening->getInleg() . "<br>";
echo "Rendement: " . ($beleggingsRekening->getRendement() * 100) . "%<br>";
?>
