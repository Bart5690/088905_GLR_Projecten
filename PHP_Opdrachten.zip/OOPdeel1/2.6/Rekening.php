<?php
class Rekening {
    protected $rekeningNummer;
    private $naamEigenaar;
    private $saldo;
    private $opnameLimiet;
    private $maxRood;

    public function __construct($rekeningNummer, $naamEigenaar, $saldo, $opnameLimiet, $maxRood) {
        $this->rekeningNummer = $rekeningNummer;
        $this->naamEigenaar = $naamEigenaar;
        $this->saldo = $saldo;
        $this->opnameLimiet = $opnameLimiet;
        $this->maxRood = $maxRood;
    }

    public function getSaldo() {
        return $this->saldo;
    }

    public function storten($bedrag) {
        // Implementeer de storten-methode
    }

    public function opnemen($bedrag) {
        // Implementeer de opnemen-methode
    }

    public function pasOpnameLimietAan($nieuwLimiet) {
        // Implementeer het aanpassen van het opnamelimiet
    }

    public function pasMaxRoodAan($nieuwMaxRood) {
        // Implementeer het aanpassen van de maxRood
    }
}
?>

