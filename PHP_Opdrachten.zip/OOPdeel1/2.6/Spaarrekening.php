<?php
require_once 'Rekening.php';

class Spaarrekening extends Rekening {
    private $startdatum;
    private $rente;
    private $kosten;

    public function __construct($rekeningNummer, $naamEigenaar, $saldo, $opnameLimiet, $maxRood, $startdatum, $rente, $kosten) {
        parent::__construct($rekeningNummer, $naamEigenaar, $saldo, $opnameLimiet, $maxRood);
        $this->startdatum = $startdatum;
        $this->rente = $rente;
        $this->kosten = $kosten;
    }

    public function berekenMaandbedrag() {
        // Implementeer de berekening van het maandbedrag
        // Voeg het toe aan het saldo
    }

    public function pasRenteAan($nieuweRente) {
        // Implementeer het aanpassen van de rente
    }

    public function getRente() {
        return $this->rente;
    }

    public function getKosten() {
        return $this->kosten;
    }
}
?>

