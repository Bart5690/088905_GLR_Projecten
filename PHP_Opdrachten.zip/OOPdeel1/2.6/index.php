<!DOCTYPE html>
<html>
<head>
    <title>Opdracht 2.6 - Overerving</title>
</head>
<body>
<h1>Opdracht 2.6 - Overerving</h1>
<h2>Rekeninggegevens</h2>

<?php
    include 'opdracht26.php';
    ?>

</body>
</html>
