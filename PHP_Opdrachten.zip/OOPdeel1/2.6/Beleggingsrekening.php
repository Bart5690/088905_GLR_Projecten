<?php
require_once 'Rekening.php';

class Beleggingsrekening extends Rekening {
    private $startdatum;
    private $inleg;
    private $rendement;

    public function __construct($rekeningNummer, $naamEigenaar, $saldo, $opnameLimiet, $maxRood, $startdatum, $inleg, $rendement) {
        parent::__construct($rekeningNummer, $naamEigenaar, $saldo, $opnameLimiet, $maxRood);
        $this->startdatum = $startdatum;
        $this->inleg = $inleg;
        $this->rendement = $rendement;
    }

    public function berekenNieuweSaldo() {
        // Implementeer de berekening van het nieuwe saldo
    }

    public function getInleg() {
        return $this->inleg;
    }

    public function getRendement() {
        return $this->rendement;
    }
}
?>
