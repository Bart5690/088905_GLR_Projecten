<?php
session_start();

// Include de Rekening class
require_once('Rekening.php');

// Functie om de rekeningen array uit de sessie te halen of een nieuwe lege array aan te maken
function getRekeningenFromSession() {
    return isset($_SESSION['rekeningen']) ? $_SESSION['rekeningen'] : [];
}

// Functie om de rekeningen array terug in de sessie op te slaan
function saveRekeningenToSession($rekeningen) {
    $_SESSION['rekeningen'] = $rekeningen;
}

// Formulier verwerking voor het aanmaken van een nieuwe rekening
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['createRekening'])) {
    // Verkrijg de input waarden
    $rekeningNummer = $_POST['rekeningNummer'];
    $naamEigenaar = $_POST['naamEigenaar'];
    $saldo = floatval($_POST['saldo']);
    $opnameLimiet = floatval($_POST['opnameLimiet']);
    $maxRood = floatval($_POST['maxRood']);

    // Maak een nieuwe rekening
    $rekening = new Rekening($rekeningNummer, $naamEigenaar, $saldo, $opnameLimiet, $maxRood);

    // Voeg de nieuwe rekening toe aan de array van rekeningen
    $rekeningen = getRekeningenFromSession();
    $rekeningen[] = $rekening;

    // Sla de array met rekeningen terug op in de sessie
    saveRekeningenToSession($rekeningen);
}

// Formulier verwerking voor het storten van geld op een rekening
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['storten'])) {
    // Verkrijg de input waarden
    $rekeningIndex = $_POST['rekeningIndex'];
    $bedrag = floatval($_POST['bedrag']);

    // Haal de rekeningen array uit de sessie
    $rekeningen = getRekeningenFromSession();

    // Voer de storten() methode uit op de geselecteerde rekening
    $rekeningen[$rekeningIndex]->storten($bedrag);

    // Sla de array met rekeningen terug op in de sessie
    saveRekeningenToSession($rekeningen);
}

// Formulier verwerking voor het opnemen van geld van een rekening
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['opnemen'])) {
    // Verkrijg de input waarden
    $rekeningIndex = $_POST['rekeningIndex'];
    $bedrag = floatval($_POST['bedrag']);

    // Haal de rekeningen array uit de sessie
    $rekeningen = getRekeningenFromSession();

    // Voer de opnemen() methode uit op de geselecteerde rekening
    $rekeningen[$rekeningIndex]->opnemen($bedrag);

    // Sla de array met rekeningen terug op in de sessie
    saveRekeningenToSession($rekeningen);
}

// Haal de rekeningen array uit de sessie
$rekeningen = getRekeningenFromSession();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opdracht 2.7 - Rekeningen</title>
</head>
<body>

<h2>Rekeningen</h2>

<!-- Formulier voor het aanmaken van een nieuwe rekening -->
<form method="POST">
    <h3>Nieuwe Rekening</h3>
    <label for="rekeningNummer">Rekeningnummer:</label>
    <input type="text" name="rekeningNummer" required><br>
    <label for="naamEigenaar">Naam Eigenaar:</label>
    <input type="text" name="naamEigenaar" required><br>
    <label for="saldo">Saldo:</label>
    <input type="number" name="saldo" step="0.01" required><br>
    <label for="opnameLimiet">Opnamelimiet:</label>
    <input type="number" name="opnameLimiet" step="0.01" required><br>
    <label for="maxRood">Maximaal Rood:</label>
    <input type="number" name="maxRood" step="0.01" required><br>
    <button type="submit" name="createRekening">Maak Rekening</button>
</form>

<hr>

<!-- Tabel voor het tonen van alle rekeningen -->
<table border="1">
    <tr>
        <th>Rekeningnummer</th>
        <th>Naam Eigenaar</th>
        <th>Saldo</th>
        <th>Opnamelimiet</th>
        <th>Maximaal Rood</th>
        <th>Acties</th>
    </tr>
    <?php foreach ($rekeningen as $index => $rekening): ?>
        <tr>
            <td><?= $rekening->getRekeningNummer(); ?></td>
            <td><?= $rekening->getNaamEigenaar(); ?></td>
            <td><?= $rekening->getSaldo(); ?></td>
            <td><?= $rekening->getOpnameLimiet(); ?></td>
            <td><?= $rekening->getMaxRood(); ?></td>
            <td>
                <!-- Formulier voor het storten van geld -->
                <form method="POST">
                    <input type="hidden" name="rekeningIndex" value="<?= $index; ?>">
                    <label for="bedrag">Bedrag:</label>
                    <input type="number" name="bedrag" step="0.01" required>
                    <button type="submit" name="storten">Storten</button>
                </form>

                <!-- Formulier voor het opnemen van geld -->
                <form method="POST">
                    <input type="hidden" name="rekeningIndex" value="<?= $index; ?>">
                    <label for="bedrag">Bedrag:</label>
                    <input type="number" name="bedrag" step="0.01" required>
                    <button type="submit" name="opnemen">Opnemen</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>


