<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

class rekening {
    private $rekeningNummer;
    private $naamEigenaar;
    private $saldo;
    private $opnameLimiet;
    private $maxRood;

    public function __construct($rekeningNummer, $naamEigenaar, $saldo, $opnameLimiet, $maxRood) {
        $this->rekeningNummer = $rekeningNummer;
        $this->naamEigenaar = $naamEigenaar;
        $this->saldo = $saldo;
        $this->opnameLimiet = $opnameLimiet;
        $this->maxRood = $maxRood;
    }

    public function storten($bedrag) {
        // Implementeer de storten logica hier
        // Controleer bijvoorbeeld of het bedrag een positief getal is
        $this->saldo += $bedrag;
    }

    public function opnemen($bedrag) {
        // Implementeer de opnemen logica hier
        // Voer controles uit zoals het opnamelimiet en maxRood
        $this->saldo -= $bedrag;
    }




    public function getRekeningNummer() {
        return $this->rekeningNummer;
    }

    public function getNaamEigenaar() {
        return $this->naamEigenaar;
    }

    public function getSaldo() {
        return $this->saldo;
    }

    public function getOpnameLimiet() {
        return $this->opnameLimiet;
    }

    public function getMaxRood() {
        return $this->maxRood;
    }

    // ... (bestaande code hier)


}
?>

