<?php
include('Rekening.php');

$rekening1 = new Rekening('12345', 'John Doe', 1000, 500, -1000);
$rekening2 = new Rekening('67890', 'Jane Smith');

$rekeninggegevens = array($rekening1, $rekening2);

echo json_encode($rekeninggegevens);
?>
