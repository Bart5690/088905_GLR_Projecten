<?php
class Rekening {
    private $rekeningNummer;
    private $naamEigenaar;
    private $saldo;
    private $opnameLimiet;
    private $maxRood;

    public function __construct($rekeningNummer, $naamEigenaar, $saldo = 0, $opnameLimiet = 0, $maxRood = 0) {
        $this->rekeningNummer = $rekeningNummer;
        $this->naamEigenaar = $naamEigenaar;
        $this->saldo = $saldo;
        $this->opnameLimiet = $opnameLimiet;
        $this->maxRood = $maxRood;
    }
}
?>
