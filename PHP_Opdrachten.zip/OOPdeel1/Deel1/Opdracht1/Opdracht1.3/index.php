<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nederlandse Datum</title>
</head>
<body>
<h1>Nederlandse Datum</h1>

<?php
// Include de functies
include('functies.php');

// Test de functie nlDatum() met volledig jaartal
$datumVoluit = nlDatum('1974-05-14');
echo "Datum (voluit): $datumVoluit<br>";

// Test de functie nlDatum() met afgekort jaartal
$datumAfgekort = nlDatum('1974-05-14', false);
echo "Datum (afgekort): $datumAfgekort<br>";
?>
</body>
</html>
