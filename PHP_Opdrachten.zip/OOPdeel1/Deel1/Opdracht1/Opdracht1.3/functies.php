<?php
function nlDatum($datum, $voluit = true) {
    $maanden = array(
        '01' => 'januari', '02' => 'februari', '03' => 'maart',
        '04' => 'april', '05' => 'mei', '06' => 'juni',
        '07' => 'juli', '08' => 'augustus', '09' => 'september',
        '10' => 'oktober', '11' => 'november', '12' => 'december'
    );

    $datumOnderdelen = explode('-', $datum);
    $dag = ltrim($datumOnderdelen[2], '0'); // Verwijder eventuele leidende nullen

    if ($voluit) {
        $jaar = $datumOnderdelen[0];
    } else {
        $jaar = substr($datumOnderdelen[0], -2);
    }

    $maand = $maanden[$datumOnderdelen[1]];

    return "$dag $maand $jaar";
}
?>

