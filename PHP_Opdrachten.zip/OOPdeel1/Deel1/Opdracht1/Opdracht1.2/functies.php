
<?php
function berekenKamer($lengte, $breedte, $hoogte = null) {
    if ($hoogte === null) {
        $oppervlakte = $lengte * $breedte;
        return $oppervlakte;
    } else {
        $inhoud = $lengte * $breedte * $hoogte;
        return $inhoud;
    }
}
?>
