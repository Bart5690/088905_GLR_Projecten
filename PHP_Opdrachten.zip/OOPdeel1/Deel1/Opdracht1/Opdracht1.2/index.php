<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kamer Berekening</title>
</head>
<body>
<h1>Kamer Berekening</h1>

<?php
include('functies.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lengte = $_POST["lengte"];
    $breedte = $_POST["breedte"];
    $hoogte = $_POST["hoogte"];
    $resultaat = berekenKamer($lengte, $breedte, $hoogte);
    echo "Het resultaat is: $resultaat";
}
?>

<form method="post" action="">
    Lengte: <input type="text" name="lengte" required><br>
    Breedte: <input type="text" name="breedte" required><br>
    Hoogte (optioneel): <input type="text" name="hoogte"><br>
    <input type="submit" value="Bereken">
</form>
</body>
</html>
