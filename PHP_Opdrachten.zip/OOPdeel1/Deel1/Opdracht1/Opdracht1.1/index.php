<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Getal Conversie</title>
</head>
<body>
<h1>Getal Conversie</h1>
<form method="post" action="">
    Voer een getal in: <input type="text" name="getal" required><br><br>
    <input type="submit" name="decimaal_naar_binair" value="Van decimaal naar binair">
    <input type="submit" name="binair_naar_decimaal" value="Van binair naar decimaal">
    <input type="submit" name="decimaal_naar_hexadecimaal" value="Van decimaal naar hexadecimaal">
    <input type="submit" name="hexadecimaal_naar_binair" value="Van hexadecimaal naar binair">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $getal = $_POST["getal"];

    if (isset($_POST["decimaal_naar_binair"])) {
        $binair = decbin($getal);
        echo "Het binair equivalent van $getal is: $binair";
    } elseif (isset($_POST["binair_naar_decimaal"])) {
        $decimaal = bindec($getal);
        echo "Het decimaal equivalent van $getal is: $decimaal";
    } elseif (isset($_POST["decimaal_naar_hexadecimaal"])) {
        $hexadecimaal = dechex($getal);
        echo "Het hexadecimaal equivalent van $getal is: $hexadecimaal";
    } elseif (isset($_POST["hexadecimaal_naar_binair"])) {
        $decimaal = hexdec($getal);
        $binair = decbin($decimaal);
        echo "Het binair equivalent van het hexadecimale getal $getal is: $binair";
    }
}
?>
</body>
</html>
