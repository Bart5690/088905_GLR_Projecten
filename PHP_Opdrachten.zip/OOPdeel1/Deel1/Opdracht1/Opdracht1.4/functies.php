<?php
function magStemmen($leeftijd) {
    // Controleer of de leeftijd een getal is
    if (is_numeric($leeftijd)) {
        // Bepaal of de leeftijd oud genoeg is om te stemmen (18 jaar of ouder)
        if ($leeftijd >= 18) {
            return true;
        } else {
            return false;
        }
    } else {
        return false; // Geen geldige numerieke invoer
    }
}
?>
