<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mag Stemmen</title>
</head>
<body>
<h1>Mag Stemmen</h1>

<?php
// Include de functies
include('functies.php');

// Test de functie magStemmen() met verschillende leeftijden
$leeftijd1 = 22;
$leeftijd2 = "tekst"; // Ongeldige invoer, geen getal

if (magStemmen($leeftijd1)) {
    echo "Je mag stemmen, want je bent 18 jaar of ouder.";
} else {
    echo "Je mag niet stemmen, want je bent jonger dan 18 jaar.";
}

echo "<br>";

if (magStemmen($leeftijd2)) {
    echo "Je mag stemmen, want je bent 18 jaar of ouder.";
} else {
    echo "Je mag niet stemmen, want de ingevoerde leeftijd is geen geldig getal.";
}
?>
</body>
</html>
