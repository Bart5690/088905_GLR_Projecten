
    


<?php
include('../Controller/Rekening.php');

$rekening1 = new Rekening();
$rekening1->rekeningNummer = "NL66INGB0001234567";
$rekening1->naamEigenaar = "Bart van Wijk";
$rekening1->saldo = 817;
$rekening1->opnameLimiet = 500;
$rekening1->maxRood = 500;

$rekening2 = new Rekening();
$rekening2->rekeningNummer = "NL66INGB0001271036";
$rekening2->naamEigenaar = "Skip Kruidenier";
$rekening2->saldo = 20;
$rekening2->opnameLimiet = 5;
$rekening2->maxRood = 40;

$rekening3 = new Rekening();
$rekening3->rekeningNummer = "NL66INGB0001202183";
$rekening3->naamEigenaar = "Lucas Huisman";
$rekening3->saldo = 70;
$rekening3->opnameLimiet = 50;
$rekening3->maxRood = 100;


$rekening1->storten(1000);
$rekening1->opnemen(500);
$rekening1->toonSaldo();
$rekening1->pasOpnameLimietAan(1500);
$rekening1->pasMaxRoodAan(1000);

$rekening2->storten(50);
$rekening2->opnemen(30);
$rekening2->toonSaldo();
$rekening2->pasOpnameLimietAan(10);
$rekening2->pasMaxRoodAan(50);

$rekening3->storten(30);
$rekening3->opnemen(80);
$rekening3->toonSaldo();
$rekening3->pasOpnameLimietAan(200);
$rekening3->pasMaxRoodAan(150);

echo $rekening1;


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <? echo $rekening1; ?>
    
</body>
</html>