<?php
class Rekening {
    public $rekeningNummer;
    public $naamEigenaar;
    public $saldo;
    public $opnameLimiet;
    public $maxRood;

    public function storten($bedrag) {
        if (is_numeric($bedrag) && $bedrag >= 0) {
            $this->saldo += round($bedrag, 2);
            echo "Storting van €" . number_format($bedrag, 2) . " succesvol.<br>";
        } else {
            echo "Fout: Ongeldig stortingsbedrag.<br>";
        }
    }

    public function opnemen($bedrag) {
        if (is_numeric($bedrag) && $bedrag >= 0) {
            if ($bedrag <= $this->opnameLimiet && ($this->saldo - $bedrag) >= $this->maxRood) {
                $this->saldo -= round($bedrag, 2);
                echo "Opname van €" . number_format($bedrag, 2) . " succesvol.<br>";
            } else {
                echo "Fout: Ongeldig opnamebedrag of saldo is ontoereikend.<br>";
            }
        } else {
            echo "Fout: Ongeldig opnamebedrag.<br>";
        }
    }

    public function pasOpnameLimietAan($nieuwLimiet) {
        if (is_numeric($nieuwLimiet) && $nieuwLimiet >= 0) {
            $this->opnameLimiet = $nieuwLimiet;
            echo "Opnamelimiet is aangepast naar €" . number_format($nieuwLimiet, 2) . ".<br>";
        } else {
            echo "Fout: Ongeldig opnamelimiet.<br>";
        }
    }

    public function pasMaxRoodAan($nieuwMaxRood) {
        if (is_numeric($nieuwMaxRood)) {
            $this->maxRood = $nieuwMaxRood;
            echo "Maximaal negatief saldo is aangepast naar €" . number_format($nieuwMaxRood, 2) . ".<br>";
        } else {
            echo "Fout: Ongeldig maximaal negatief saldo.<br>";
        }
    }

    public function toonSaldo() {
        echo "Het saldo op de rekening is €" . number_format($this->saldo, 2) . ".<br>";
    }
}
?>
