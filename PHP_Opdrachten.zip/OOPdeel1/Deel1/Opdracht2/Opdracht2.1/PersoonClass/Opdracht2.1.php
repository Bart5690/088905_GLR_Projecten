<?php
include('../Controller/Rekening.php');

$rekening1 = new Rekening();
$rekening1->rekeningNummer = "NL66INGB0001234567";
$rekening1->naamEigenaar = "Bart van Wijk";
$rekening1->saldo = 817;
$rekening1->opnameLimiet = 500;
$rekening1->maxRood = 500;

$rekening2 = new Rekening();
$rekening2->rekeningNummer = "NL66INGB0001271036";
$rekening2->naamEigenaar = "Skip Kruidenier";
$rekening2->saldo = 20;
$rekening2->opnameLimiet = 5;
$rekening2->maxRood = 40;

$rekening3 = new Rekening();
$rekening3->rekeningNummer = "NL66INGB0001202183";
$rekening3->naamEigenaar = "Lucas Huisman";
$rekening3->saldo = 70;
$rekening3->opnameLimiet = 50;
$rekening3->maxRood = 100;
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opdracht 2.1</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <h1>Rekening 1</h1>
    <p>Rekeningnummer: <?php echo $rekening1->rekeningNummer; ?></p>
    <p>Naam eigenaar: <?php echo $rekening1->naamEigenaar; ?></p>
    <p>Saldo: <?php echo $rekening1->saldo; ?></p>
    <p>Opnamelimiet: <?php echo $rekening1->opnameLimiet; ?></p>
    <p>Maximaal rood staan: <?php echo $rekening1->maxRood; ?></p>

    <h1>Rekening 2</h1>
    <p>Rekeningnummer: <?php echo $rekening2->rekeningNummer; ?></p>
    <p>Naam eigenaar: <?php echo $rekening2->naamEigenaar; ?></p>
    <p>Saldo: <?php echo $rekening2->saldo; ?></p>
    <p>Opnamelimiet: <?php echo $rekening2->opnameLimiet; ?></p>
    <p>Maximaal rood staan: <?php echo $rekening2->maxRood; ?></p>

    <h1>Rekening 3</h1>
    <p>Rekeningnummer: <?php echo $rekening3->rekeningNummer; ?></p>
    <p>Naam eigenaar: <?php echo $rekening3->naamEigenaar; ?></p>
    <p>Saldo: <?php echo $rekening3->saldo; ?></p>
    <p>Opnamelimiet: <?php echo $rekening3->opnameLimiet; ?></p>
    <p>Maximaal rood staan: <?php echo $rekening3->maxRood; ?></p>
</div>
</body>
</html>

