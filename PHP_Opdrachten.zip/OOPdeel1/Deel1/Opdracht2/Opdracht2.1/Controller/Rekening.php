<?php
class Rekening {
public $rekeningNummer;
public $naamEigenaar;
public $saldo;
public $opnameLimiet;
public $maxRood;
}

