document.addEventListener('DOMContentLoaded', function () {
    const userCardsContainer = document.getElementById('userCards');
    const loginModalElement = document.getElementById('loginModal');
    const loginModal = new bootstrap.Modal(loginModalElement, {
        keyboard: false
    });
    const passwordInput = document.getElementById('password');
    const loginForm = document.getElementById('loginForm');
    const attemptsRemainingSpan = document.createElement('span'); // Element voor resterende inlogpogingen
    const retryTimerSpan = document.createElement('span'); // Element voor retry timer
    let currentUserId;
    let currentUserAvatar;
    let currentUserPin;
    let loginAttempts = 0;
    let loginLocked = false;
    let retryTimeLeft = 0;
    let retryTimerInterval;

    // Voeg het logo toe bovenaan de pagina
    const header = document.createElement('img');
    header.src = 'header.png'; // Voeg het juiste pad naar de afbeelding toe
    header.classList.add('img-fluid', 'mb-4', 'mx-auto', 'd-block'); // Voeg Bootstrap-klassen toe om de afbeelding responsief te maken en in het midden te plaatsen
    header.style.maxWidth = '400px'; // Pas de maximale breedte van de afbeelding aan
    userCardsContainer.parentNode.insertBefore(header, userCardsContainer);

    // Voeg het element voor resterende inlogpogingen toe onder het wachtwoordveld
    passwordInput.insertAdjacentElement('afterend', attemptsRemainingSpan);

    // Voeg het element voor de retry timer toe onder het wachtwoordveld
    passwordInput.insertAdjacentElement('afterend', retryTimerSpan);

    // Haal de gebruikersinformatie op van de API
    fetch('https://steijlen.sd-lab.nl/ex-digsign/users')
        .then(response => response.json())
        .then(users => {
            users.forEach(user => {
                const userCard = document.createElement('div');
                userCard.classList.add('col-md-3', 'col-sm-4', 'col-xs-2', 'mb-4');
                userCard.innerHTML = `
                    <div class="card">
                        <img src="${user.Avatar}" class="card-img-top" alt="Avatar">
                        <div class="card-body">
                            <h5 class="card-title">User ${user.ID}</h5>
                            <p class="card-text">${user.Voornaam} ${user.Achternaam}</p>
                            <button type="button" class="btn btn-primary" data-user-id="${user.ID}" data-user-avatar="${user.Avatar}" data-user-pin="${user.PIN}">Login</button>
                        </div>
                    </div>
                `;
                userCard.querySelector('.btn-primary').addEventListener('click', () => {
                    openLoginModal(user.ID, user.Avatar, user.PIN);
                });
                userCardsContainer.appendChild(userCard);
            });
        })
        .catch(error => console.error('Error fetching users:', error));

    // Open het inlogmodal
    function openLoginModal(userId, userAvatar, userPin) {
        currentUserId = userId;
        currentUserAvatar = userAvatar;
        currentUserPin = userPin;
        loginModal.show();
    }

    // Voer de inlogcontrole uit
    loginForm.addEventListener('submit', (event) => {
        event.preventDefault();
        if (loginLocked) return; // Als inloggen vergrendeld is, stop met inloggen

        const enteredPin = passwordInput.value;

        // Controleer of de ingevoerde PIN overeenkomt met de PIN van de gebruiker
        if (enteredPin === currentUserPin) {
            loginModal.hide();
            checkLoginAttempts(currentUserId);
        } else {
            passwordInput.style.borderColor = 'red'; // Maak het wachtwoordveld rood
            passwordInput.value = ''; // Leeg het wachtwoordveld
            passwordInput.placeholder = 'Wachtwoord fout'; // Toon een foutbericht onder het veld
            loginAttempts++;
            attemptsRemainingSpan.textContent = `Pogingen over: ${5 - loginAttempts}`; // Toon het aantal resterende inlogpogingen

            if (loginAttempts >= 5) {
                loginLocked = true; // Vergrendel inloggen voor een minuut na 5 mislukte pogingen
                startRetryTimer(); // Start de retry timer
            }
        }
    });

    // Functie om de loginpogingen te controleren
    function checkLoginAttempts(userId) {
        fetch(`https://steijlen.sd-lab.nl/ex-digsign/registrations/${userId}`)
            .then(response => response.json())
            .then(registrations => {
                const lastWeek = new Date();
                lastWeek.setDate(lastWeek.getDate() - 7);

                const recentRegistrations = registrations.filter(registration => {
                    const registrationDate = new Date(registration.CREATED_ON_TS);
                    return registrationDate >= lastWeek;
                });

                const loginCount = recentRegistrations.length;
                let message;
                if (loginCount >= 3) {
                    message = `Goed zo! Je hebt ${loginCount} keer ingelogd.`;
                } else {
                    message = `Je moet iets meer je best doen. Je hebt ${loginCount} keer ingelogd.`;
                }

                displayLoggedInUser(message);
            })
            .catch(error => console.error('Error fetching registrations:', error));
    }

    // Sluit het inlogmodal wanneer op 'X' wordt geklikt
    document.querySelector('.close').addEventListener('click', () => {
        loginModal.hide();
        resetLoginForm(); // Reset het inlogformulier
    });

    // Functie om de ingelogde gebruiker weer te geven
    function displayLoggedInUser(message) {
        userCardsContainer.innerHTML = `
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Login Successful</h5>
                            <p class="card-text">${message}</p>
                            <button type="button" class="btn btn-danger" id="logoutBtn">Uitloggen</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <img src="${currentUserAvatar}" class="img-fluid" alt="Avatar">
                </div>
            </div>
        `;
    
        // Voeg een event listener toe aan de uitlogknop
        const logoutBtn = document.getElementById('logoutBtn');
        logoutBtn.addEventListener('click', logout);
    }
    
    // Functie om uit te loggen
    function logout() {
        // Hier zou je extra logica kunnen toevoegen, bijvoorbeeld om sessiegegevens te wissen of door te sturen naar de inlogpagina.
        // Voor nu gaan we gewoon de pagina herladen om terug te keren naar de inlogpagina.
        window.location.reload();
    }
    

    // Functie om het inlogformulier te resetten
    function resetLoginForm() {
        passwordInput.style.borderColor = ''; // Reset de randkleur van het wachtwoordveld
        passwordInput.value = ''; // Leeg het wachtwoordveld
        passwordInput.placeholder = 'Wachtwoord'; // Herstel de standaardplaceholder
        attemptsRemainingSpan.textContent = ''; // Verwijder het resterende pogingenbericht
    }

    // Functie om de retry timer te starten
    function startRetryTimer() {
        retryTimeLeft = 60; // Stel de retry timer in op 60 seconden
        retryTimerInterval = setInterval(updateRetryTimer, 1000); //
    }

    // Functie om de retry timer bij te werken en weer te geven
    function updateRetryTimer() {
        if (retryTimeLeft > 0) {
            retryTimeLeft--;
            const minutes = Math.floor(retryTimeLeft / 60);
            const seconds = retryTimeLeft % 60;
            const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
            retryTimerSpan.textContent = `Wacht ${formattedTime} voor nieuwe poging`;
        } else {
            clearInterval(retryTimerInterval); // Stop de retry timer
            loginLocked = false; // Ontgrendel inloggen
            loginAttempts = 0; // Reset het aantal inlogpogingen
            attemptsRemainingSpan.textContent = ''; // Verwijder het resterende pogingenbericht
            retryTimerSpan.textContent = ''; // Verwijder de retry timer weergave
        }
    }
});
